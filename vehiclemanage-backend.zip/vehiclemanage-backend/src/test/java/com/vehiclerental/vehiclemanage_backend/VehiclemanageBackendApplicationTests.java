package com.vehiclerental.vehiclemanage_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehiclemanageBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
